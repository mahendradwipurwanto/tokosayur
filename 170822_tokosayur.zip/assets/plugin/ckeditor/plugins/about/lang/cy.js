﻿/*
Copyright (c) 2003-2021, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
*/
CKEDITOR.plugins.setLang( 'about', 'cy', {
	copy: 'Hawlfraint &copy; $1. Cedwir pob hawl.',
	dlgTitle: 'About CKEditor 4', // MISSING
	moreInfo: 'Am wybodaeth ynghylch trwyddedau, ewch i\'n gwefan:'
} );
