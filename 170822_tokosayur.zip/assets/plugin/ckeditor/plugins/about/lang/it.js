﻿/*
Copyright (c) 2003-2021, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
*/
CKEDITOR.plugins.setLang( 'about', 'it', {
	copy: 'Copyright &copy; $1. Tutti i diritti riservati.',
	dlgTitle: 'Informazioni su CKEditor 4',
	moreInfo: 'Per le informazioni sulla licenza si prega di visitare il nostro sito:'
} );
